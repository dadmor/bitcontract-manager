var componentContracts = Vue.extend({
	template: 
	`<div>
		<table>
			<tr>
				<th>Contract name</th>
				<th></th>
				<th>Owner</th>
				<th>State</th>
				<th>Actions</th>
			</tr>
			
			<tr 
				v-for="(item) in $root.storageContracts"
				:class="['hovered']"
				@click="openContract(item)"
				>
				<td>{{item.contractName}}</td>
				<td>{{item.contractId}}</td>
				<td>{{item.ownerEmail}}</td>
				<td>
					{{$root.getActiveShemaName(item)}}
					<div v-if="item.signs.length===0">
						(blank)
					</div>
				</td>
				<td>
					<span class="link" v-on:click.stop="removeContract(item)">
						remove
					</span>
				</td>
			</tr>

		</table>
	</div>`,
	props: ['me'],
	data: function(){
		return {
			
		}
	},
	methods: {
		openContract(_item){
			this.$root.me = _item;
			this.$root.app.view = 'component-form';
		},
		removeContract(_item){
			alert(_item.contractId);
		}
	},
})
Vue.component('component-contracts', componentContracts);