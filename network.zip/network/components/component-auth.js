var componentAuth = Vue.extend({
	template: 
	`<div>
		<fieldset>
			<div>
				<label>Login</label>
				<input v-model="user.login" />
			</div>

			<div>
				<label>Email</label>
				<input v-model="user.email" />
			</div>

			<div>
				<label>Long and serious password</label>
				<input v-model="user.password" />
			</div>
			<button 
				class="jsdft-button full" 
				@click="$root.loginUser(user)">
				Authenticate
			</button>
		</fieldset>
	</div>
`,
	data: function(){
		return {
			user:{
				login: "",
				email: "",
				password: "",
			}	
		}
	},
})
Vue.component('component-auth', componentAuth);