var componentForm = Vue.extend({
	template: 
	`<div>
		<h2>Contract page: {{activeAttachment.name}}</h2>
		<div class="flex">
			<a 
				v-for="(item) in me.attachments"
				:class="[
					'jsdft-button', 
					'bgbg300', 
					'full', 
					{active: $root.app.view===activeAttachment.name}]" 
				href="#empty" 
				@click="$root.app.view = item.name">{{item.name}}</a>
		</div>
		<fieldset>
			<div v-for="(field, key, value) in activeAttachment.schema" >
				<div v-if="field.type === 'string'">
					<label>{{field.title}}</label>
					<input v-model="form[key]"/>
				</div>
				<div v-if="field.type === 'value'">
					<label>{{field.title}}</label>
					<input type="number"/>
				</div>
			</div>
		</fieldset>
		<button class="jsdft-button full" @click="runAction(me, form)">
			action
		</button>
	</div>`,
	props: ['me'],
	data: function(){
		return {
			activeAttachment: this.$root.getActiveAttachment(this.me),
			form: {},
		}
	},
	methods: {
		runAction(_contract, _form){
			this.$root.contractAction(_contract, _form);
		},
	},
})
Vue.component('component-form', componentForm);