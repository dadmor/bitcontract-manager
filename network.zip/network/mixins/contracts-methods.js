const contractMethods = {
    methods : {
        sign(_attr){
			/* guardian */
			if(!this.app.RSA){
				alert('login first');
				return false;
			}
			/* update datalayer */
			for (var key in _attr.form) {
				_attr.contract.dataLayer[key].push(_attr.form[key]);
			}

			if(_attr.contract.signs.length == 0){
				/* make initial sign */
				_attr.contract.signs.push({
					'public': this.app.publicKey,
					'encrypt': cryptico.encrypt(
						JSON.stringify(_attr.contract), 
						this.app.publicKey, 
						this.app.RSA).cipher
				});
			}
			// var DecryptionResult = cryptico.decrypt(EncryptionResult.cipher, this.app.RSA);
		
           $root.me = _attr.contract;
           console.log('signed:', $root.me);
		},
		setDataLayer(_attr){
			/* guardian */
			// if(!this.app.RSA){
			// 	alert('login first');
			// 	return false;
			// }

			// _contract.dataLayer[key].push(_value);

		}
		
    }
};